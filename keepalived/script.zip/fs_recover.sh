#!/bin/sh
 
FS_CLI_PROG='/usr/local/freeswitch/bin/fs_cli'
FS_CLI_HOST='127.0.0.1'
FS_CLI_PORT='8021'
FS_CLI_PASS='ClueCon'
#PROFILES='sofia.superpipi.cn'
#VIP='172.16.100.12'
 
fs_cli() {
  $FS_CLI_PROG -H $FS_CLI_HOST -P $FS_CLI_PORT -p $FS_CLI_PASS -x "$1"
}
 
save_log(){
count=1
str_tmp="`date +%Y-%m-%d_%H:%M:%S` "
while [ $# -ge 1 ];do
str_tmp="$str_tmp $1"
count=count+1
shift
done
echo $str_tmp >>/var/log/check_fs_`date +%Y-%m-%d`.log
}
save_log "本节点切换为主用状态，开始接管切换前的通话。"
fs_cli "sofia recover"
fs_cli "raloadxml"
exit 0