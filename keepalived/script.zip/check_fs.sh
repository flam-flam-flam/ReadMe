#!/bin/sh

FS_CLI_PROG='/usr/local/freeswitch/bin/fs_cli'
FS_CLI_HOST='127.0.0.1'
FS_CLI_PORT='8021'
FS_CLI_PASS='ClueCon'
#PROFILES='sofia.superpipi.cn'
VIP='192.168.43.16'

fs_cli() {
  $FS_CLI_PROG -H $FS_CLI_HOST -P $FS_CLI_PORT -p $FS_CLI_PASS -x "$1"
}

sofia_profile_started() {
  fs_cli "sofia xmlstatus" | wc -l
}

save_log(){
count=1
str_tmp="`date +%Y-%m-%d_%H:%M:%S` "
while [ $# -ge 1 ];do
str_tmp="$str_tmp $1"
count=count+1
shift
done
echo $str_tmp >>/var/log/check_fs_`date +%Y-%m-%d`.log
}

check_vrrp(){
ip a|grep $VIP|wc -l
}
	
check_fs_service(){
ps -ef |grep freeswitch|grep -v 'grep'|wc -l
}

#     fs_cli "sofia recover"
#for p in $PROFILES; do
   if [ `sofia_profile_started ` -eq 0 ]; then
     # echo "$p DOWN"
     log_str="freeswitch DOWN"
     save_log $log_str
     if [ `check_vrrp` -eq 1 ];then
         save_log "本机已经绑定VRRP，即将重启keepalived和FreeSWITCH。"
         service keepalived restart
         save_log "vrrp切换完成！"
         if [ `check_fs_service` -eq 1 ];then
             save_log "freeswitch服务正在操作中。"
         else
            #service freeswitch restart
            save_log "freeswitch重启成功！"
         fi
     else
         if [ `check_fs_service` -eq 1 ];then
             save_log "freeswitch服务正在操作中。 "
         else
             save_log "本机没有绑定VRRP，重启FreeSWITCH。"
             service freeswitch restart
             save_log "freeswitch重启成功！"
         fi
     fi
     exit 1
  fi
#done
save_log "freeswitch状态检测:OK!"
#echo "OK"
exit 0